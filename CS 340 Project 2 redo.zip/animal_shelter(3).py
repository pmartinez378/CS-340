from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter:
    def __init__(self, user, password, host, port, db, col):
        uri = f'mongodb://{user}:{password}@{host}:{port}/{db}?authSource=AAC'
        self.client = MongoClient(uri)
        self.database = self.client[db]
        self.collection = self.database[col]
        print("Connection to MongoDB established successfully!")

    def create(self, data):
        if data is not None:
            try:
                result = self.collection.insert_one(data)
                print(f"Inserted document with ID: {result.inserted_id}")
                return True
            except Exception as e:
                print(f"Error inserting document: {e}")
                return False
        else:
            raise Exception("Nothing to save, because data parameter is empty")

    def read(self, query):
        if query is not None:
            try:
                documents = self.collection.find(query)
                results = list(documents)  # Convert cursor to list
                for doc in results:
                    print(doc)
                return results
            except Exception as e:
                print(f"Error reading documents: {e}")
                return []
        else:
            raise Exception("Query parameter is empty")

    def update(self, query, update_data):
        if query is not None and update_data is not None:
            try:
                result = self.collection.update_many(query, {"$set": update_data})
                print(f"Modified {result.modified_count} document(s)")
                return result.modified_count
            except Exception as e:
                print(f"Error updating document(s): {e}")
                return 0
        else:
            raise Exception("Query or update data parameter is empty")

    def delete(self, query):
        if query is not None:
            try:
                result = self.collection.delete_many(query)
                print(f"Deleted {result.deleted_count} document(s)")
                return result.deleted_count
            except Exception as e:
                print(f"Error deleting document(s): {e}")
                return 0
        else:
            raise Exception("Query parameter is empty")


# Usage Example:
if __name__ == "__main__":
    # Connection variables
    USER = 'aacuser'
    PASS = 'chicken'
    HOST = 'nv-desktop-services.apporto.com'
    PORT = 30806
    DB = 'AAC'
    COL = 'animals'

    # Initialize the AnimalShelter class
    shelter = AnimalShelter(USER, PASS, HOST, PORT, DB, COL)

    # Sample data to insert
    sample_data = {
        "_id": ObjectId(),
        "age_upon_outcome": "2 years",
        "animal_id": "A123456",
        "animal_type": "Dog",
        "breed": "Labrador Retriever",
        "color": "Yellow",
        "date_of_birth": "2020-01-01",
        "outcome_type": "Adoption"
    }

    # Call create method to insert data
    shelter.create(sample_data)

    # Call read method to find documents
    query = {"animal_type": "Dog"}
    shelter.read(query)

    # Call update method to modify documents
    update_data = {"age_upon_outcome": "3 years"}
    shelter.update(query, update_data)

    # Call delete method to remove documents
    delete_query = {"animal_id": "A123456"}
    shelter.delete(delete_query)

